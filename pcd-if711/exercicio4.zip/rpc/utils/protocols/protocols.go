package protocols

// Protocols name constants
const (
	TCP = "tcp"
	UDP = "udp"
	RPC = "rpc"
)
