package constants

// Constant value for client/server application
const (
	NumRepetitions int = 10
)
